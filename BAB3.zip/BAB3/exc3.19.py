# Exercise 3.19 PyCaret classification on Breast Cancer data
import pandas as pd
from sklearn import datasets

try:
    from pycaret import classification
except ImportError:
    print('Exercise 3.19 requires the optional pycaret package.')
else:
    cancer = datasets.load_breast_cancer(as_frame=True)
    data = cancer.data.copy()
    data['Target'] = cancer.target
    data = pd.DataFrame(data)
    classification.setup(data=data, target='Target', session_id=0, verbose=False)
    print(classification.compare_models())