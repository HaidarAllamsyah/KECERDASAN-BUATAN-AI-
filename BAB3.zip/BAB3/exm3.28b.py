# Example 3.28B LazyPredict classification
import lazypredict
from lazypredict.Supervised import LazyClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=1
)

clf = LazyClassifier(n_jobs=1)
models, predictions = clf.fit(X_train, X_test, y_train, y_test)
print(models)
