# Example 3.28D LazyPredict regression
import lazypredict
from lazypredict.Supervised import LazyRegressor, REGRESSORS
from sklearn import datasets
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X, y = fetch_california_housing(return_X_y=True, as_frame=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.1, random_state=1
)

regression_models = [
    estimator
    for name, estimator in REGRESSORS
    if name != 'GaussianProcessRegressor'
]
reg = LazyRegressor(
    regressors=regression_models,
    timeout=30,
    n_jobs=1,
)
models, predictions = reg.fit(X_train, X_test, y_train, y_test)
print(models)
