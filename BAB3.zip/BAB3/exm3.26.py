# Example 3.26 AutoML regression
# The auto_ml package is no longer maintained for current Python versions.
try:
    from auto_ml import Predictor
    from auto_ml.utils import get_boston_dataset
except ImportError:
    print('Example 3.26 requires the legacy auto_ml package.')
    print('Use exc3.18.py for the supported California Housing regression.')
else:
    df_train, df_test = get_boston_dataset()
    column_descriptions = {'MEDV': 'output', 'CHAS': 'categorical'}
    ml_predictor = Predictor(
        type_of_estimator='regressor',
        column_descriptions=column_descriptions,
    )
    ml_predictor.train(df_train)
    ml_predictor.score(df_test, df_test.MEDV)
