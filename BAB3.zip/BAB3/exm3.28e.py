# Example 3.28E Plot LazyPredict regression R-squared
import matplotlib.pyplot as plt
from lazypredict.Supervised import LazyRegressor, REGRESSORS
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split

X, y = fetch_california_housing(return_X_y=True, as_frame=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.1, random_state=1
)
regression_models = [
    estimator
    for name, estimator in REGRESSORS
    if name != 'GaussianProcessRegressor'
]
regressor = LazyRegressor(
    verbose=0,
    ignore_warnings=True,
    regressors=regression_models,
    timeout=30,
    n_jobs=1,
)
models, predictions = regressor.fit(X_train, X_test, y_train, y_test)

plt.figure(figsize=(10, 5))
plt.plot(models.index, models['R-Squared'], '-s')
plt.xticks(rotation=90)
plt.ylabel('R-Squared')
plt.title('LazyPredict Regression R-Squared')
plt.tight_layout()
plt.show()
